<h1 align="center">
    Outward Game Settings
</h1>
<br/>
<div align="center">
  <img src="https://raw.githubusercontent.com/GymMed/Outward-Game-Settings/refs/heads/main/preview/images/Logo.png" alt="Outward game setting to require enchantment recipe when enchanting."/>
</div>

<div align="center">
	<a href="https://thunderstore.io/c/outward/p/GymMed/GameSettings/">
		<img src="https://img.shields.io/thunderstore/dt/GymMed/GameSettings" alt="Thunderstore Downloads">
	</a>
	<a href="https://github.com/GymMed/Outward-Game-Settings/releases/latest">
		<img src="https://img.shields.io/thunderstore/v/GymMed/GameSettings" alt="Thunderstore Version">
	</a>
</div>

This Outward mod allows you to change the way game works.

<details>
    <summary>Require Enchantment Recipe To Enchant</summary>

_Attempting to enchant an item without the required enchantment recipe in your inventory (pocket or backpack) will display an error and cancel the process. Config setting: `RequireRecipeToAllowEnchant`._<br>
![Picture](https://raw.githubusercontent.com/GymMed/Outward-Game-Settings/refs/heads/main/preview/images/1.png)

</details>

<details>
    <summary>Consume Enchantment on Use</summary>

_Successfully enchanting an item consumes the enchantment recipe from your inventory. Recommended to use together with `Enchanting Requires Enchantment` setting. Config setting: `UseRecipeOnEnchanting`_<br>
![Picture](https://raw.githubusercontent.com/GymMed/Outward-Game-Settings/refs/heads/main/preview/images/2.png)

</details>

<details>
    <summary>Enchanting Success Chance</summary>

_Enchanting an item can fail based on a configurable success rate. Config setting: `EnchantingSuccessChance`_<br>
![Picture](https://raw.githubusercontent.com/GymMed/Outward-Game-Settings/refs/heads/main/preview/images/3.png)

</details>

<details>
    <summary>Play Audio on Enchanting Completion</summary>

_Plays custom sound effects when the EnchantmentTable.DoneEnchanting event occurs. Success and failure each trigger different audio clips. Enabled with config setting: `PlayAudioOnEnchantingDone`_<br>
![Picture](https://raw.githubusercontent.com/GymMed/Outward-Game-Settings/refs/heads/main/preview/images/3.png)

</details>

## How to change settings?

Currently all settings can be changed in `BepInEx\config\gymmed.outwardgamesettings.cfg`.

## How to set up

To manually set up, do the following

1. Create the directory: `Outward\BepInEx\plugins\OutwardGameSettings\`.
2. Extract the archive into any directory(recommend empty).
3. Move the contents of the plugins\ directory from the archive into the `BepInEx\plugins\OutwardGameSettings\` directory you created.
4. It should look like `Outward\BepInEx\plugins\OutwardGameSettings\OutwardGameSettings.dll`
   Launch the game, open inventory and view details of item(Equipment or weapon) it should display all available enchantments.

### If you liked the mod leave a star on [GitHub](https://github.com/GymMed/Outward-Game-Settings) it's free
